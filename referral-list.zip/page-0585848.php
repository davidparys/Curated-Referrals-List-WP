<?php get_header(); ?>

<div class="c-bg border m-2 p-3 rounded-sm">
    <?php _e( 'Thanks for submitting, we will check very soon if this referral link is valid. If yes you will see it on our page!', 'referral_list' ); ?> 
</div>            

<?php get_footer(); ?>