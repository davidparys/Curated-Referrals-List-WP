<?php get_header(); ?>

<div class="container">
    <div>
        <?php echo do_shortcode('[acfe_form ID="43"]'); ?>
    </div>
</div>            

<?php get_footer(); ?>